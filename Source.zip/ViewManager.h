///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"

// GLFW library
#include "GLFW/glfw3.h" 

class ViewManager
{
public:
	// constructor
	ViewManager(
		ShaderManager* pShaderManager);
	// destructor
	~ViewManager();

	// mouse position callback for mouse interaction with the 3D scene
	static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);

	// scroll callback for mouse wheel interaction
	static void ScrollCallback(GLFWwindow* window, double xOffset, double yOffset);

	/***************************************************************************************************/
	/*** Had to move the ProcessKeyboardEvents from a private variable to public so that ***/
	/***      the MainCode.cpp could access it                                            ***/
	/***                            ~Douglas Rowland                                      ***/

	// process keyboard events for interaction with the 3D scene
	void ProcessKeyboardEvents();

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// active OpenGL display window
	GLFWwindow* m_pWindow;

	// Camera movement speed
	float cameraSpeed;

	// projection mode: true for orthographic, false for perspective
	bool bOrthographicProjection;

public:
	// create the initial OpenGL display window
	GLFWwindow* CreateDisplayWindow(const char* windowTitle);
	
	// prepare the conversion from 3D object display to 2D scene display
	void PrepareSceneView();
};