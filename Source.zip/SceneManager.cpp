///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <GLFW/glfw3.h> // Included this file to be able to pan camera ~Douglas Rowland

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}
// Camera control variables ~ Douglas Rowland
// Added z-axis control to pan up and down in 3D
glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 5.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
float cameraSpeed = 0.01f; // Can decrease/increase for smoother panning
float yaw = -90.0f;
float pitch = 0.0f;
float lastX = 400, lastY = 300;
bool firstMouse = true;

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	bReturn = CreateGLTexture(
		"../../Utilities/textures/rusticwood.jpg",
		"table");

	bReturn = CreateGLTexture(
		"../../Utilities/textures/blackmouse.jpg",
		"blackmouse");

	bReturn = CreateGLTexture(
		"../../Utilities/textures/stainless.jpg",
		"stainless");

	bReturn = CreateGLTexture(
		"../../Utilities/textures/matte-grey.jpg",
		"matte-grey");

	bReturn = CreateGLTexture(
		"../../Utilities/textures/darkgrey.jpg",
		"darkgrey");

	bReturn = CreateGLTexture(
		"../../Utilities/textures/gold-seamless-texture.jpg",
		"gold");

	bReturn = CreateGLTexture(
		"../../Utilities/textures/white.jpg",
		"white");

	bReturn = CreateGLTexture(
		"../../Utilities/textures/watchband.jpg",
		"watchband");

	bReturn = CreateGLTexture(
		"../../Utilities/textures/watchface.png",
		"watchface");

	bReturn = CreateGLTexture(
		"../../Utilities/textures/night.jpg",
		"backdrop");

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodMaterial.ambientStrength = 0.0001f;
	woodMaterial.diffuseColor = glm::vec3(0.003f, 0.003f, 0.003f);
	woodMaterial.specularColor = glm::vec3(0.001f, 0.001f, 0.001f);
	woodMaterial.shininess = 0.01;
	woodMaterial.tag = "wood";

	OBJECT_MATERIAL blackmouseMaterial;
	blackmouseMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	blackmouseMaterial.ambientStrength = 0.3f;
	blackmouseMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	blackmouseMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	blackmouseMaterial.shininess = 22.0;
	blackmouseMaterial.tag = "mouse";

	m_objectMaterials.push_back(blackmouseMaterial);

	OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	glassMaterial.ambientStrength = 0.3f;
	glassMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	glassMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	glassMaterial.shininess = 85.0;
	glassMaterial.tag = "glass";

	m_objectMaterials.push_back(glassMaterial);

	OBJECT_MATERIAL goldMaterial;
	goldMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	goldMaterial.ambientStrength = 0.7f;
	goldMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	goldMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	goldMaterial.shininess = 70.0;
	goldMaterial.tag = "metal";

	m_objectMaterials.push_back(goldMaterial);

	OBJECT_MATERIAL emissiveMaterial;
	emissiveMaterial.ambientColor = glm::vec3(1.0f, 1.0f, 1.0f);
	emissiveMaterial.ambientStrength = 800.0f;
	emissiveMaterial.diffuseColor = glm::vec3(0.0f, 0.0f, 0.0f);  // No diffuse reflection
	emissiveMaterial.specularColor = glm::vec3(0.0f, 0.0f, 0.0f); // No specular reflection
	emissiveMaterial.shininess = 0.0f;
	emissiveMaterial.tag = "emissiveGlow";

	m_objectMaterials.push_back(emissiveMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render 
	// the 3D scene with custom lighting - to use the default rendered 
	// lighting then comment out the following line
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Light source 1
	m_pShaderManager->setVec3Value("lightSources[0].position", -3.0f, 40.0f, 6.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.5f, 0.5f, 0.5f); // Further reduced ambient light
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.01f, 0.03f, 0.04f); // Further reduced diffuse light
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.01f, 0.01f, 0.01f); // Further reduced specular light
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 3.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.01f); // Reduced specular intensity

	// Light source 2 (Desk Lamp light)
	m_pShaderManager->setVec3Value("lightSources[1].position", 9.0f, 12.0f, -7.0f); // Position near the lamp shade
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor",0.05f, 0.025f, 0.02f); // Reduced ambient light
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.02f, 0.08f, 0.06f); // Reduced diffuse light
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.04f, 0.04f, 0.04f); // Reduced specular highlights
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 30.1f); // Control the focus
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.4f); // Reduced specular intensity

	// Light Source 3 - Additional ambient light
	m_pShaderManager->setVec3Value("lightSources[2].position", 5.0f, 10.0f, 15.0f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.05f, 0.05f, 0.05f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.03f, 0.03f, 0.03f); 
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.15f, 10.15f, 0.15f); 
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 50.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.1f); 

	// Light Source 4 - Additional ambient light               
	m_pShaderManager->setVec3Value("lightSources[3].position", -1.0f, 6.0f, 5.0f);
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.007f, 0.005f, 0.005f); 
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.3f, 0.3f, 0.3f); 
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.0015f, 0.0015f, 0.0015f); 
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 0.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.01f);


}


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load the texture image files for the textures applied
	// to objects in the 3D scene
	LoadSceneTextures();
	
	// define the materials that will be used for the objects
	// in the 3D scene
	DefineObjectMaterials();

	// add and defile the light sources for the 3D scene
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	/*** Loading all of the shape meshes needed ***/
	/***              Douglas Rowland           ***/
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadPyramid3Mesh();
	m_basicMeshes->LoadPyramid4Mesh();
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadTorusMesh();	
}


/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	RenderBackdrop();
	RenderTable();
	RenderMouse();
	RenderSunglasses();
	RenderController();
	RenderAppleWatch();
	RenderDeskLamp();
}

/***********************************************************
 *  RenderBackdrop()
 *
 *  This method is called to render the shapes for the table
 *  object.
 ***********************************************************/
void SceneManager::RenderBackdrop()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh ***/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 20.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 15.0f, -18.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("backdrop");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("glass");

	// draw the mesh with transformation values - this plane is used for the backdrop
	m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 *  RenderTable()
 *
 *  This method is called to render the shapes for the table
 *  object.
 ***********************************************************/
void SceneManager::RenderTable()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(40.0f, 1.0f, 20.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);


	SetShaderTexture("table");
	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
}
	/****************************************************************/


/***********************************************************
*  RenderMouse()
*
*  This method is used to render the 3D mouse object
***********************************************************/
	// Drawing the basic shape meshes for Mouse object
void SceneManager::RenderMouse()
{
	// Base position of the mouse object
	glm::vec3 basePosition = glm::vec3(3.0f, 0.0f, 3.0f); 

	//Declare the variables, individual component transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// Body of the mouse (Sphere-> Rear)
	scaleXYZ = glm::vec3(1.4f, 0.6f, 0.8f); // Adjusted to look like the main body
	XrotationDegrees = 75.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.4f, 2.05f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("blackmouse");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("mouse");

	m_basicMeshes->DrawHalfSphereMesh();

	// Body of the mouse (tapered cylinder-> Rear left)
	scaleXYZ = glm::vec3(1.3f, 0.65f, 1.1f); // Adjusted to look like the main body
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-0.25f, 0.4f, 1.65f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Body of the mouse (tapered cylinder-> Rear right)
	scaleXYZ = glm::vec3(1.3f, 0.65f, 1.1f); // Adjusted to look like the main body
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.25f, 0.4f, 1.65f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Body of the mouse (Sphere)
	scaleXYZ = glm::vec3(1.4f, 1.4f, 2.65f); // Adjusted to look like the main body
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.2f, 0.0f)+ basePosition; // Adjusted to be on top of the base
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("darkgrey");
	m_basicMeshes->DrawHalfSphereMesh(); //Used half-sphere for top half of mouse body

	// Body of the mouse (Sphere-> Front left)
	scaleXYZ = glm::vec3(1.0f, 0.9f, 1.7f); // Adjusted to look like the main body
	XrotationDegrees = 0.0f;
	YrotationDegrees = -30.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-0.6f, 0.0f, -1.3)+ basePosition; 
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawHalfSphereMesh(); 

	// Body of the mouse (Sphere-> Front right)
	scaleXYZ = glm::vec3(1.0f, 0.9f, 1.7f); // Adjusted to look like the main body
	XrotationDegrees = 0.0f;
	YrotationDegrees = 30.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.6f, 0.0f, -1.3f)+ basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawHalfSphereMesh();

	// Scroll wheel for the Mouse
	scaleXYZ = glm::vec3(0.5f, 0.5f, 0.5f); 
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 0.9f, -1.4f)+ basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderTexture("matte-grey");
	m_basicMeshes->DrawTorusMesh();

	// Button separation line 
	scaleXYZ = glm::vec3(1.2f, 0.4f, 0.1f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = -16.0f;

	positionXYZ = glm::vec3(0.0f, 1.0f, -1.05f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawTorusMesh();

	/****************** Right Body of Mouse**********************/
	/************************************************************/
	// Body of the mouse (cone-> Right side)
	scaleXYZ = glm::vec3(0.3f, 2.6f, 0.3f); // Adjusted to look like the main body
	XrotationDegrees = 90.0f;
	YrotationDegrees = 35.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(1.1f, 0.7f, -1.2f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawConeMesh();

	// Body of the mouse (cone(lower)-> Right side)
	scaleXYZ = glm::vec3(0.1f, 2.6f, 0.3f); // Adjusted to look like the main body
	XrotationDegrees = -90.0f;
	YrotationDegrees = -45.0f;
	ZrotationDegrees = -5.0f;
	positionXYZ = glm::vec3(1.2f, 0.6f, 1.5f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawConeMesh();

	// Body of the mouse (cone(upper)-> Right side)
	scaleXYZ = glm::vec3(0.1f, 2.6f, 0.3f); // Adjusted to look like the main body
	XrotationDegrees = -90.0f;
	YrotationDegrees = -45.0f;
	ZrotationDegrees = -5.0f;
	positionXYZ = glm::vec3(1.1f, 0.8f, 1.5f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawConeMesh();

	// Body of the mouse (cone(upper)-> Right side)
	scaleXYZ = glm::vec3(0.1f, 2.6f, 0.3f); // Adjusted to look like the main body
	XrotationDegrees = -87.0f;
	YrotationDegrees = -45.0f;
	ZrotationDegrees = -3.0f;
	positionXYZ = glm::vec3(1.0f, 0.9f, 1.5f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawConeMesh();

	// Rigth side indent for the Mouse
	scaleXYZ = glm::vec3(1.6f, 0.7f, 0.8f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 85.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.8f, 0.55f, 0.1f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawTorusMesh();

	// Rigth side indent for the Mouse
	scaleXYZ = glm::vec3(0.3f, 0.2f, 1.4f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = -5.0f;
	ZrotationDegrees = -45.0f;

	positionXYZ = glm::vec3(1.0f, 1.0f, 0.1f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawHalfSphereMesh();

	/******************* Left Body of Mouse**********************/
	/************************************************************/
	// Body of the mouse (cone-> Right side)
	scaleXYZ = glm::vec3(0.3f, 2.6f, 0.3f); // Adjusted to look like the main body
	XrotationDegrees = 90.0f;
	YrotationDegrees = -35.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-1.1f, 0.7f, -1.2f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawConeMesh();

	// Body of the mouse (cone(lower)-> Right side)
	scaleXYZ = glm::vec3(0.1f, 2.6f, 0.3f); // Adjusted to look like the main body
	XrotationDegrees = -90.0f;
	YrotationDegrees = 45.0f;
	ZrotationDegrees = 5.0f;
	positionXYZ = glm::vec3(-1.2f, 0.6f, 1.5f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawConeMesh();

	// Body of the mouse (cone(upper)-> Right side)
	scaleXYZ = glm::vec3(0.1f, 2.6f, 0.3f); // Adjusted to look like the main body
	XrotationDegrees = -90.0f;
	YrotationDegrees = 45.0f;
	ZrotationDegrees = 5.0f;
	positionXYZ = glm::vec3(-1.1f, 0.8f, 1.5f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawConeMesh();

	// Body of the mouse (cone(upper)-> Right side)
	scaleXYZ = glm::vec3(0.1f, 2.6f, 0.3f); // Adjusted to look like the main body
	XrotationDegrees = -87.0f;
	YrotationDegrees = 45.0f;
	ZrotationDegrees = 3.0f;
	positionXYZ = glm::vec3(-1.0f, 0.9f, 1.5f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawConeMesh();

	// Rigth side indent for the Mouse
	scaleXYZ = glm::vec3(1.6f, 0.7f, 0.8f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = -85.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-0.8f, 0.55f, 0.1f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawTorusMesh();

	// Rigth side indent for the Mouse
	scaleXYZ = glm::vec3(0.3f, 0.2f, 1.4f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 5.0f;
	ZrotationDegrees = 45.0f;

	positionXYZ = glm::vec3(-1.0f, 1.0f, 0.1f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	SetShaderTexture("blackmouse");
	m_basicMeshes->DrawHalfSphereMesh();
}

/***********************************************************
 *  RenderSunglasses()
 *
 *  This method is used to render the 3D sunglasses object
 ***********************************************************/
 void SceneManager::RenderSunglasses()
{
	// Base position of the sunglasses object
	glm::vec3 basePosition = glm::vec3(-6.0f, 0.0f, 5.0f);

	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Left Lens of the Sunglasses (Half Sphere) ***/
	scaleXYZ = glm::vec3(1.0f, 1.5f, 0.1f);
	XrotationDegrees = 120.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-1.2f, 1.0f, 0.0f)+ basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.3f, 0.1f, 0.1f, 0.7f); // Dark transparent color for lenses
	SetShaderMaterial("glass");
	m_basicMeshes->DrawHalfSphereMesh();

	// Right Lens of the Sunglasses 
	scaleXYZ = glm::vec3(1.0f, 1.5f, 0.1f);
	XrotationDegrees = 120.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(1.2f, 1.0f, 0.0f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("glass");
	m_basicMeshes->DrawHalfSphereMesh();

	// Left Hinge of the Sunglasses 
	scaleXYZ = glm::vec3(0.1f, 0.05f, 0.05f);
	XrotationDegrees = 45.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	positionXYZ = glm::vec3(-2.15f, 0.82f, 0.17f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("gold");
	m_basicMeshes->DrawHalfSphereMesh();

	// Bridge of the Sunglasses
	scaleXYZ = glm::vec3(0.03f, 1.1f, 0.03f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	positionXYZ = glm::vec3(0.55f, 1.0f, 0.0f)+ basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("gold");
	m_basicMeshes->DrawCylinderMesh();

	// Left Arm of the Sunglasses 
	scaleXYZ = glm::vec3(0.05f, 3.5f, 0.05f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 10.0f;
	ZrotationDegrees = 90.0f;

	positionXYZ = glm::vec3(1.3f, 0.8f, -0.5f)+ basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("gold");
	m_basicMeshes->DrawCylinderMesh();

	//Right Arm of the Sunglasses
	XrotationDegrees = -20.0f;
	YrotationDegrees = -5.0f;
	ZrotationDegrees = 92.0f;
	positionXYZ = glm::vec3(2.15f, 0.81f, 0.14f)+ basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	
	SetShaderTexture("gold");
	m_basicMeshes->DrawCylinderMesh();

	// Left Hinge of the Sunglasses 
	scaleXYZ = glm::vec3(0.1f, 0.05f, 0.05f);
	XrotationDegrees = 45.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -90.0f;

	positionXYZ = glm::vec3(2.15f, 0.82f, 0.17f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("gold");
	m_basicMeshes->DrawHalfSphereMesh();
}

/***********************************************************
 *  RenderController()
 *
 *  This method is used to render the 3D controller object
 ***********************************************************/
 void SceneManager::RenderController()
 {
	 // Base position of the controller object
	 glm::vec3 basePosition = glm::vec3(-1.0f, 0.0f, -3.0f);

	 glm::vec3 scaleXYZ;
	 float XrotationDegrees = 0.0f;
	 float YrotationDegrees = 0.0f;
	 float ZrotationDegrees = 0.0f;
	 glm::vec3 positionXYZ;

	 // Base of the Controller 
	 scaleXYZ = glm::vec3(2.0f, 1.0f, 4.5f);
	 XrotationDegrees = 0.0f;
	 YrotationDegrees = 0.0f;
	 ZrotationDegrees = 0.0f;

	 positionXYZ = glm::vec3(-0.1f, 1.25f, 0.0f) + basePosition;
	 SetTransformations(
		 scaleXYZ,
		 XrotationDegrees,
		 YrotationDegrees,
		 ZrotationDegrees,
		 positionXYZ);

	 SetShaderTexture("blackmouse");
	 SetTextureUVScale(1.0, 1.0);
	 SetShaderMaterial("mouse");
	 m_basicMeshes->DrawBoxMesh();

	 // Right hand grip 
	 scaleXYZ = glm::vec3(0.7f, 1.65f, 0.7f); 
	 XrotationDegrees = 90.0f;
	 YrotationDegrees = 15.0f;
	 ZrotationDegrees = 70.0f;
	 positionXYZ = glm::vec3(-1.0f, 1.0f, 1.65f) + basePosition;
	 SetTransformations(
		 scaleXYZ,
		 XrotationDegrees,
		 YrotationDegrees,
		 ZrotationDegrees,
		 positionXYZ);

	 SetShaderTexture("blackmouse");
	 SetTextureUVScale(1.0, 1.0);
	 SetShaderMaterial("mouse");
	 m_basicMeshes->DrawTaperedCylinderMesh();

	 // Right hand grip bottom
	 scaleXYZ = glm::vec3(0.7f, 1.65f, 0.7f);
	 XrotationDegrees = 90.0f;
	 YrotationDegrees = 15.0f;
	 ZrotationDegrees = 70.0f;
	 positionXYZ = glm::vec3(-1.0f, 0.9f, 1.65f) + basePosition;
	 SetTransformations(
		 scaleXYZ,
		 XrotationDegrees,
		 YrotationDegrees,
		 ZrotationDegrees,
		 positionXYZ);

	 SetShaderTexture("blackmouse");
	 SetTextureUVScale(1.0, 1.0);
	 SetShaderMaterial("mouse");
	 m_basicMeshes->DrawSphereMesh();

	 // Left hand grip 
	 scaleXYZ = glm::vec3(0.7f, 1.65f, 0.7f); 
	 XrotationDegrees = 90.0f;
	 YrotationDegrees = 15.0f;
	 ZrotationDegrees = 110.0f;
	 positionXYZ = glm::vec3(-1.0f, 1.2f, -1.65f) + basePosition;
	 SetTransformations(
		 scaleXYZ,
		 XrotationDegrees,
		 YrotationDegrees,
		 ZrotationDegrees,
		 positionXYZ);

	 SetShaderTexture("blackmouse");
	 SetTextureUVScale(1.0, 1.0);
	 SetShaderMaterial("mouse");
	 m_basicMeshes->DrawTaperedCylinderMesh();

	 // Left hand grip bottom
	 scaleXYZ = glm::vec3(0.7f, 1.65f, 0.7f);
	 XrotationDegrees = 90.0f;
	 YrotationDegrees = 15.0f;
	 ZrotationDegrees = 110.0f;
	 positionXYZ = glm::vec3(-1.0f, 0.9f, -1.65f) + basePosition;
	 SetTransformations(
		 scaleXYZ,
		 XrotationDegrees,
		 YrotationDegrees,
		 ZrotationDegrees,
		 positionXYZ);

	 SetShaderTexture("blackmouse");
	 SetTextureUVScale(1.0, 1.0);
	 SetShaderMaterial("mouse");
	 m_basicMeshes->DrawSphereMesh();

	 // Left joystick
	 scaleXYZ = glm::vec3(0.1f, 0.3f, 0.1f);
	 XrotationDegrees = 0.0f;
	 YrotationDegrees = 0.0f;
	 ZrotationDegrees = 0.0f;
	 positionXYZ = glm::vec3(0.3f, 1.7f, -1.62f) + basePosition;
	 SetTransformations(
		 scaleXYZ,
		 XrotationDegrees,
		 YrotationDegrees,
		 ZrotationDegrees,
		 positionXYZ);

	 SetShaderTexture("matte-grey");
	 SetTextureUVScale(1.0, 1.0);
	 //SetShaderColor(0.5, 0.1, 0.1, 1.0);
	 SetShaderMaterial("mouse");
	 m_basicMeshes->DrawCylinderMesh();

	 // Left joystick
	 scaleXYZ = glm::vec3(0.3f, 0.15f, 0.3f);
	 XrotationDegrees = 0.0f;
	 YrotationDegrees = 0.0f;
	 ZrotationDegrees = 0.0f;
	 positionXYZ = glm::vec3(0.3f, 1.9f, -1.62f) + basePosition;
	 SetTransformations(
		 scaleXYZ,
		 XrotationDegrees,
		 YrotationDegrees,
		 ZrotationDegrees,
		 positionXYZ);

	 SetShaderTexture("matte-grey");
	 SetTextureUVScale(1.0, 1.0);
	 //SetShaderColor(0.5, 0.1, 0.1, 1.0);
	 SetShaderMaterial("mouse");
	 m_basicMeshes->DrawCylinderMesh();

	 // Left joystick
	 scaleXYZ = glm::vec3(0.1f, 0.3f, 0.1f);
	 XrotationDegrees = 0.0f;
	 YrotationDegrees = 0.0f;
	 ZrotationDegrees = 0.0f;
	 positionXYZ = glm::vec3(-0.5f, 1.7f, 1.0f) + basePosition;
	 SetTransformations(
		 scaleXYZ,
		 XrotationDegrees,
		 YrotationDegrees,
		 ZrotationDegrees,
		 positionXYZ);

	 SetShaderTexture("matte-grey");
	 SetTextureUVScale(1.0, 1.0);
	 //SetShaderColor(0.5, 0.1, 0.1, 1.0);
	 SetShaderMaterial("mouse");
	 m_basicMeshes->DrawCylinderMesh();

	 // Left joystick
	 scaleXYZ = glm::vec3(0.3f, 0.15f, 0.3f);
	 XrotationDegrees = 0.0f;
	 YrotationDegrees = 0.0f;
	 ZrotationDegrees = 0.0f;
	 positionXYZ = glm::vec3(-0.5f, 1.9f, 1.0f) + basePosition;
	 SetTransformations(
		 scaleXYZ,
		 XrotationDegrees,
		 YrotationDegrees,
		 ZrotationDegrees,
		 positionXYZ);

	 SetShaderTexture("matte-grey");
	 SetTextureUVScale(1.0, 1.0);
	 //SetShaderColor(0.5, 0.1, 0.1, 1.0);
	 SetShaderMaterial("mouse");
	 m_basicMeshes->DrawCylinderMesh();

	 // Directional Pad
	 scaleXYZ = glm::vec3(0.6f, 0.1f, 0.2f);
	 XrotationDegrees = 0.0f;
	 YrotationDegrees = 0.0f;
	 ZrotationDegrees = 0.0f;
	 positionXYZ = glm::vec3(-0.5f, 1.8f, -1.0f) + basePosition;
	 SetTransformations(
		 scaleXYZ,
		 XrotationDegrees,
		 YrotationDegrees,
		 ZrotationDegrees,
		 positionXYZ);

	 SetShaderTexture("matte-grey");
	 SetTextureUVScale(1.0, 1.0);
	 //SetShaderColor(0.5, 0.1, 0.1, 1.0);
	 SetShaderMaterial("mouse");
	 m_basicMeshes->DrawBoxMesh();

	 // Directional Pad
	 scaleXYZ = glm::vec3(0.6f, 0.1f, 0.2f);
	 XrotationDegrees = 0.0f;
	 YrotationDegrees = 90.0f;
	 ZrotationDegrees = 0.0f;
	 positionXYZ = glm::vec3(-0.5f, 1.8f, -1.0f) + basePosition;
	 SetTransformations(
		 scaleXYZ,
		 XrotationDegrees,
		 YrotationDegrees,
		 ZrotationDegrees,
		 positionXYZ);

	 SetShaderTexture("matte-grey");
	 SetTextureUVScale(1.0, 1.0);
	 //SetShaderColor(0.5, 0.1, 0.1, 1.0);
	 SetShaderMaterial("mouse");
	 m_basicMeshes->DrawBoxMesh();

	 // Buttons
	 scaleXYZ = glm::vec3(0.15f, 0.08f, 0.15f);
	 XrotationDegrees = 0.0f;
	 YrotationDegrees = 90.0f;
	 ZrotationDegrees = 0.0f;
	 positionXYZ = glm::vec3(0.5f, 1.8f, 1.6f) + basePosition;
	 SetTransformations(
		 scaleXYZ,
		 XrotationDegrees,
		 YrotationDegrees,
		 ZrotationDegrees,
		 positionXYZ);

	 SetShaderColor(0.5, 0.1, 0.1, 1.0);
	 SetShaderMaterial("mouse");
	 m_basicMeshes->DrawHalfSphereMesh();

	 // Buttons
	 scaleXYZ = glm::vec3(0.15f, 0.08f, 0.15f);
	 XrotationDegrees = 0.0f;
	 YrotationDegrees = 90.0f;
	 ZrotationDegrees = 0.0f;
	 positionXYZ = glm::vec3(0.0f, 1.8f, 1.6f) + basePosition;
	 SetTransformations(
		 scaleXYZ,
		 XrotationDegrees,
		 YrotationDegrees,
		 ZrotationDegrees,
		 positionXYZ);

	 SetShaderColor(0.1, 0.5, 0.1, 1.0);
	 SetShaderMaterial("mouse");
	 m_basicMeshes->DrawHalfSphereMesh();

	 // Buttons
	 scaleXYZ = glm::vec3(0.15f, 0.08f, 0.15f);
	 XrotationDegrees = 0.0f;
	 YrotationDegrees = 90.0f;
	 ZrotationDegrees = 0.0f;
	 positionXYZ = glm::vec3(0.25f, 1.8f, 1.35f) + basePosition;
	 SetTransformations(
		 scaleXYZ,
		 XrotationDegrees,
		 YrotationDegrees,
		 ZrotationDegrees,
		 positionXYZ);

	 SetShaderColor(1.0, 1.0, 0.0, 1.0);
	 SetShaderMaterial("mouse");
	 m_basicMeshes->DrawHalfSphereMesh();

	 // Buttons
	 scaleXYZ = glm::vec3(0.15f, 0.08f, 0.15f);
	 XrotationDegrees = 0.0f;
	 YrotationDegrees = 90.0f;
	 ZrotationDegrees = 0.0f;
	 positionXYZ = glm::vec3(0.25f, 1.8f, 1.85f) + basePosition;
	 SetTransformations(
		 scaleXYZ,
		 XrotationDegrees,
		 YrotationDegrees,
		 ZrotationDegrees,
		 positionXYZ);

	 SetShaderColor(0.1, 0.1, 0.5, 1.0);
	 SetShaderMaterial("mouse");
	 m_basicMeshes->DrawHalfSphereMesh();
 }
	

/***********************************************************
 *  RenderAppleWatch()
 *
 *  This method is used to render the 3D smartwatch object
 ***********************************************************/
void SceneManager::RenderAppleWatch()
{
	// Base position of the Apple Watch object
	glm::vec3 basePosition = glm::vec3(-10.0f, 0.3f, 3.0f);

    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    // Body of the Watch 
    scaleXYZ = glm::vec3(0.48f, 1.5f, 1.8f);
    XrotationDegrees = 0.0f;
    YrotationDegrees = 90.0f;
    ZrotationDegrees = 0.0f;

    positionXYZ = glm::vec3(0.0f, 0.95f, 0.1f) + basePosition;
    SetTransformations(
        scaleXYZ, 
        XrotationDegrees, 
        YrotationDegrees, 
        ZrotationDegrees, 
        positionXYZ);

	SetShaderTexture("watchface");
	SetShaderMaterial("glass");
	SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();

	// Body of the Watch 
	scaleXYZ = glm::vec3(0.5f, 1.5f, 2.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 1.0f, 0.0f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("stainless");
	SetShaderMaterial("metal");
	SetTextureUVScale(1.0, 1.0);
	m_basicMeshes->DrawBoxMesh();

    // Watch Strap  
    scaleXYZ = glm::vec3(2.5f, 1.5f, 2.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
    positionXYZ = glm::vec3(0.0f, 0.0f, -2.0f) + basePosition;
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

	SetShaderTexture("watchband");
	SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawCylinderMesh(false, false, true); //only draw the side for the band

}

/***********************************************************
 *  RenderDeskLamp()
 *
 *  This method is used to render the 3D smartwatch object
 ***********************************************************/
void SceneManager::RenderDeskLamp()
{
	// Base position of the Desk Lamp object
	glm::vec3 basePosition = glm::vec3(16.0f, 0.5f, -6.0f);

	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// Base of Desk Lamp 
	scaleXYZ = glm::vec3(3.0f, 0.75f, 3.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f); // Dark grey color
	m_basicMeshes->DrawCylinderMesh();

	// Body of Desk Lamp 
	scaleXYZ = glm::vec3(0.35f, 6.5f, 0.35f);
	XrotationDegrees = -10.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -10.0f;
	positionXYZ = glm::vec3(0.0f, 0.5f, 0.0f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f); // Black strap
	m_basicMeshes->DrawCylinderMesh();

	// Upper Body of Desk Lamp 
	scaleXYZ = glm::vec3(0.35f, 5.2f, 0.35f);
	XrotationDegrees = 10.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 10.0f;
	positionXYZ = glm::vec3(1.1f, 5.8f, -1.1f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f); // Black strap
	m_basicMeshes->DrawCylinderMesh();

	// Lamp Shade of Desk Lamp 
	scaleXYZ = glm::vec3(2.0f, 2.0f, 2.0f);
	XrotationDegrees = -45.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -45.0f;
	positionXYZ = glm::vec3(0.0f, 13.0f, 0.0f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f); 
	m_basicMeshes->DrawHalfSphereMesh();

	// Lamp Shade of Desk Lamp 
	scaleXYZ = glm::vec3(2.0f, 3.2f, 2.0f);
	XrotationDegrees = -45.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -45.0f;
	positionXYZ = glm::vec3(-2.0f, 11.5f, 1.5f) + basePosition;
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f); 
	m_basicMeshes->DrawCylinderMesh(false, false, true); // Draw outside lamp shade

	// Add Light Bulb (Emissive Sphere)
	scaleXYZ = glm::vec3(1.0f, 1.0f, 1.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-1.0f, 12.5f, 1.0f) + basePosition;  // Position it inside the lamp shade
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("white");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("emissiveGlow");
	m_basicMeshes->DrawSphereMesh();
}